#include<stdio.h>
int max(int a,int b)
{
    if(a>b)
    { //printf("\n%d",a);
     return a;
 }
     else
     { //printf("\n%d",b);
     return b;
 }
}
int lcs(long int X[],long int Y[],long int Z[], int m, int n,int o)
                     
{
    int L[m+1][n+1][o+1], i,j,k;
    
 
       for (i=0; i<=m; i++)
    {
        for (j=0; j<=n; j++)
        {
            for (k=0; k<=o; k++)
            {
                if (i == 0 || j == 0||k==0)
                    L[i][j][k] = 0;
 
                else if (X[i-1] == Y[j-1] && X[i-1]==Z[k-1])
                    L[i][j][k] = L[i-1][j-1][k-1] + 1;
 
                else
                    L[i][j][k] = max(max(L[i-1][j][k],
                                         L[i][j-1][k]),
                                     L[i][j][k-1]);
            }
        }
    }
 
   
    return L[m][n][o];
}
int main()
{
	long int X[100],Y[100],Z[100];
	int i,m,n,o,ans;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	scanf("%ld",&X[i]);
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%ld",&Y[i]);
	scanf("%d",&o);
	for(i=0;i<o;i++)
	scanf("%ld",&Z[i]);
	ans=lcs(X,Y,Z,m,n,o);
	
  printf("\n%d", ans);
 
  return 0;
}

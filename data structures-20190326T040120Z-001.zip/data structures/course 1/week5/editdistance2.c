#include<stdio.h>
#include<string.h>
 
 int min(int a,int b)
 {
	 if(a<b)
	 return a;
	 return b;
 }
int minEditDistance(char src[], char dest[], int len1, int len2)
{
    int i, j;
 
 
    int edit[len1+1][len2+1];
 
    for(i=0;i<=len1;i++)
        edit[i][0]=i;    
 
    for(j=0;j<=len2;j++)
        edit[0][j]=j;   
 
    
    for(i=1;i<=len1;i++)
    {
        for(j=1;j<=len2;j++)
        {    
            if(src[i-1]==dest[j-1])
            {
                edit[i][j]=edit[i-1][j-1];
            }
 
    
            else
            {
      
                int x=1+edit[i-1][j];    
                int y=1+edit[i][j-1];    
                int z=1+edit[i-1][j-1];  
 
                edit[i][j]=min(x,min(y,z));
 
            }
        }
    }
 
    
    return edit[len1][len2];
 
}
 
 
int main()
{
    char src[105],dest[105];
    int len1,len2;
     scanf("%s",src);
     scanf("%s",dest);
    //gets(src);
    //gets(dest);
 
     len1=strlen(src); 
     len2=strlen(dest); 
 
    printf("%d",minEditDistance(src,dest,len1,len2));
 
    return 0;
}

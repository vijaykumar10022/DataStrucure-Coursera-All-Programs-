#include<stdio.h>
int max(int a,int b)
{
    if(a>b)
    { //printf("\n%d",a);
     return a;
 }
     else
     { //printf("\n%d",b);
     return b;
 }
    
}
int c[101][101];
int lcs(long int X[],long int Y[], int m, int n)
{
	
	int i, j;
	for(j=0;j<=n;j++)
	{
	c[0][j]=0;
	//printf("%d\t",c[0][j]);
}
	for(i=0;i<=m;i++)
	{
	c[i][0]=0;
	//printf("%d\t",c[i][0]);
}
	
	for(i=0;i<m;i++)
	for(j=0;j<n;j++)
		if (X[i]==Y[j])
		c[i+1][j+1]=c[i][j]+1;
		else
		{
			//printf("\n%d",c[i][j-1]);
			//printf("\n%d",c[i-1][j]);
		c[i+1][j+1]=max(c[i+1][j],c[i][j+1]);
	}
	return c[m][n];
}
int main()
{
	long int X[100],Y[100];
	int i,m,n,ans;
	scanf("%d",&m);
	for(i=0;i<m;i++)
	scanf("%ld",&X[i]);
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%ld",&Y[i]);
	ans=lcs(X,Y,m,n);
	
  printf("\n%d", ans);
 
  return 0;
}


